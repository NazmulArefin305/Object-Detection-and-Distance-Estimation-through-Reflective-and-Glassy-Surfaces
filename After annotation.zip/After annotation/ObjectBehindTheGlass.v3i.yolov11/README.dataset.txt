# ObjectBehindTheGlass > 2025-04-15 1:45pm
https://universe.roboflow.com/nazmul-6pv5t/objectbehindtheglass

Provided by a Roboflow user
License: CC BY 4.0

